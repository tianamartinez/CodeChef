using UnityEngine;

public class RotateRobot : MonoBehaviour
{
    public float speed = 40f;

    void Update()
    {
        transform.Rotate(Vector3.up * speed * Time.deltaTime);
    }
}
