using UnityEngine;

public class RobotMovimiento : MonoBehaviour
{
    public float velocidad = 3f;
    private Rigidbody rb;
    private ChefController chef;
    private bool estabaMoviendose = false;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        chef = GetComponent<ChefController>();
    }

    void FixedUpdate()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector3 movimiento = new Vector3(horizontal, 0f, vertical).normalized;

        // Mover con Rigidbody para evitar conflicto con el Animator
        if (movimiento.magnitude > 0.1f)
        {
            Vector3 nuevaPosicion = rb.position + movimiento * velocidad * Time.fixedDeltaTime;
            rb.MovePosition(nuevaPosicion);

            // Rotar hacia donde se mueve
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                Quaternion.LookRotation(movimiento),
                10f * Time.fixedDeltaTime);
        }

        // Cambiar animación
        bool seMueve = movimiento.magnitude > 0.1f;
        if (seMueve && !estabaMoviendose)
        {
            if (chef != null) chef.OnStartCooking();
            estabaMoviendose = true;
        }
        else if (!seMueve && estabaMoviendose)
        {
            if (chef != null) chef.SetState(ChefController.ChefState.Idle);
            estabaMoviendose = false;
        }
    }
}