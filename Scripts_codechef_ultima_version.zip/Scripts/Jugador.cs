using UnityEngine;

/// <summary>
/// Clase Jugador con encapsulación (getters/setters).
/// Demuestra: propiedades privadas con acceso controlado mediante métodos públicos.
/// </summary>
public class Jugador : MonoBehaviour
{
    [Header("Estadísticas del Jugador")]
    [SerializeField] private string nombreJugador = "Héroe";
    [SerializeField] private int vida = 100;
    [SerializeField] private int vidaMaxima = 100;
    [SerializeField] private int monedas = 0;

    [Header("Movimiento")]
    public float velocidad = 5f;
    public float velocidadRotacion = 10f;

    // --- ENCAPSULACIÓN: propiedades con acceso controlado ---

    public string NombreJugador
    {
        get => nombreJugador;
        set => nombreJugador = value;
    }

    public int Vida
    {
        get => vida;
        private set => vida = Mathf.Clamp(value, 0, vidaMaxima); // No puede salir del rango
    }

    public int Monedas
    {
        get => monedas;
        private set => monedas = Mathf.Max(0, value); // No puede ser negativo
    }

    // --- MÉTODOS PÚBLICOS para modificar estado de forma controlada ---

    public void RecibirDanio(int cantidad)
    {
        Vida -= cantidad;
        Debug.Log($"{nombreJugador} recibió {cantidad} de daño. Vida: {Vida}/{vidaMaxima}");

        if (Vida <= 0)
            Morir();
    }

    public void Curar(int cantidad)
    {
        Vida += cantidad;
        Debug.Log($"{nombreJugador} se curó {cantidad} puntos. Vida: {Vida}/{vidaMaxima}");
    }

    public void AgregarMonedas(int cantidad)
    {
        Monedas += cantidad;
        Debug.Log($"{nombreJugador} obtuvo {cantidad} monedas. Total: {Monedas}");
    }

    private void Morir()
    {
        Debug.Log($"{nombreJugador} ha muerto. Game Over.");
        // Aquí podrías cargar la escena de Game Over
        // SceneManager.LoadScene("GameOver");
    }

    // --- MOVIMIENTO BÁSICO ---

    private void Update()
    {
        MoverJugador();
    }

    private void MoverJugador()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector3 direccion = new Vector3(horizontal, 0f, vertical).normalized;

        if (direccion.magnitude > 0.1f)
        {
            // Rotar suavemente hacia la dirección de movimiento
            Quaternion rotacionObjetivo = Quaternion.LookRotation(direccion);
            transform.rotation = Quaternion.Slerp(transform.rotation, rotacionObjetivo, Time.deltaTime * velocidadRotacion);

            // Mover
            transform.Translate(Vector3.forward * velocidad * Time.deltaTime);
        }
    }

    // Muestra estadísticas en consola al presionar Tab
    private void LateUpdate()
    {
        if (Input.GetKeyDown(KeyCode.Tab))
            Debug.Log($"=== {nombreJugador} === Vida: {Vida}/{vidaMaxima} | Monedas: {Monedas}");
    }
}
