using UnityEngine;
using TMPro;

public class ChefDialogue : MonoBehaviour
{
    public TextMeshProUGUI dialogueText;

    string[] frases = {
        "Bienvenido a CodeChef! Aprender a programar es como cocinar.",
        "Una variable guarda ingredientes: int edad = 20;",
        "Un loop repite pasos, como revolver la sopa hasta que hierva.",
        "Una funcion es una receta dentro de tu programa.",
        "El if-else decide: si la cebolla esta dorada, sigue. Si no, espera!",
        "Un array es una lista de ingredientes ordenados.",
        "Debuggear es probar la receta y corregir el sabor.",
        "Cada error es una leccion, no te rindas chef!"
    };

    private int index = 0;
    private float timer = 0f;

    void Start()
    {
        if (dialogueText != null)
            dialogueText.text = frases[0];
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= 3f)
        {
            timer = 0f;
            index = (index + 1) % frases.Length;
            if (dialogueText != null)
                dialogueText.text = frases[index];
        }
    }

    public void SetState(int state)
    {
        if (state == 2)
            dialogueText.text = "Excelente! Tu codigo salio perfecto chef!";
    }
}