using UnityEngine;

public class ChefController : MonoBehaviour
{
    private Animator animator;
    public ChefDialogue dialogue; // AGREGA ESTO

    public enum ChefState { Idle=0, Cooking=1, Celebrate=2, Error=3 }

   void Awake()
{
    animator = GetComponent<Animator>();
}

void Start()
{
    SetState(ChefState.Idle);
}

    public void SetState(ChefState newState)
    {
        animator.SetInteger("State", (int)newState);
        if (dialogue != null) dialogue.SetState((int)newState); // AGREGA ESTO
    }

    public void OnCodeSuccess()
    {
        SetState(ChefState.Celebrate);
        Invoke("ReturnToIdle", 2f);
    }

    public void OnCodeError()
    {
        SetState(ChefState.Error);
        Invoke("ReturnToIdle", 1.5f);
    }

    public void OnStartCooking()
    {
        SetState(ChefState.Cooking);
    }

    private void ReturnToIdle()
    {
        SetState(ChefState.Idle);
    }
}