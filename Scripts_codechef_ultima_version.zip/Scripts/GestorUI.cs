using UnityEngine;
using TMPro;

/// <summary>
/// Gestiona los mensajes de interacción en pantalla.
/// Patrón Singleton: una sola instancia accesible desde cualquier script.
/// </summary>
public class GestorUI : MonoBehaviour
{
    public static GestorUI instancia;   // Singleton

    [Header("Referencias UI")]
    public TextMeshProUGUI textoInteraccion;
    public TextMeshProUGUI textoVida;
    public TextMeshProUGUI textoMonedas;

    [Header("Configuración")]
    public float tiempoMensaje = 3f;    // Segundos que dura el mensaje
    private float temporizador = 0f;

    private void Awake()
    {
        // Singleton: solo existe una instancia
        if (instancia == null)
            instancia = this;
        else
            Destroy(gameObject);
    }

    private void Update()
    {
        // Oculta el mensaje después del tiempo configurado
        if (temporizador > 0f)
        {
            temporizador -= Time.deltaTime;
            if (temporizador <= 0f)
                textoInteraccion.text = "";
        }
    }

    /// <summary>
    /// Muestra un mensaje en pantalla temporalmente.
    /// Llámalo desde cualquier script: GestorUI.instancia.MostrarMensaje("texto");
    /// </summary>
    public void MostrarMensaje(string mensaje)
    {
        if (textoInteraccion == null) return;
        textoInteraccion.text = mensaje;
        temporizador = tiempoMensaje;
    }

    /// <summary>
    /// Muestra u oculta el mensaje de proximidad (Presiona E para...)
    /// </summary>
    public void MostrarProximidad(string mensaje, bool visible)
    {
        if (textoInteraccion == null) return;
        if (visible)
        {
            textoInteraccion.text = mensaje;
            temporizador = 0f; // No desaparece solo mientras esté cerca
        }
        else
        {
            textoInteraccion.text = "";
        }
    }

    /// <summary>
    /// Actualiza el texto de vida del jugador en pantalla.
    /// </summary>
    public void ActualizarVida(int vida, int vidaMaxima)
    {
        if (textoVida != null)
            textoVida.text = $"❤ {vida} / {vidaMaxima}";
    }

    /// <summary>
    /// Actualiza el texto de monedas en pantalla.
    /// </summary>
    public void ActualizarMonedas(int monedas)
    {
        if (textoMonedas != null)
            textoMonedas.text = $"💰 {monedas}";
    }
}
