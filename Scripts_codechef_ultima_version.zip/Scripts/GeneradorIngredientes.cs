// GeneradorIngredientes.cs - Genera ingredientes automaticamente
using UnityEngine;
public class GeneradorIngredientes : MonoBehaviour
{
public GameObject prefabIngrediente;
public float tiempoEntreSpawn = 3f;
public float rangoSpawn = 3f;
private float temporizador;
void Start()
{
temporizador = tiempoEntreSpawn;
SpawnIngrediente(); // Genera uno al inicio
}
void Update()
{
temporizador -= Time.deltaTime;
if (temporizador <= 0f)
{
SpawnIngrediente();
temporizador = tiempoEntreSpawn;
}
}
void SpawnIngrediente()
{
// Posicion aleatoria dentro del rango
Vector3 posicion = new Vector3(
Random.Range(-rangoSpawn, rangoSpawn),
0.5f,
Random.Range(-rangoSpawn, rangoSpawn)
);
// Crear la instancia del Prefab
Instantiate(prefabIngrediente, posicion,
Quaternion.identity);
}
}
