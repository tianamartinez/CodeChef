using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MiniJuego : MonoBehaviour {

    public ChefController chef;
    public TextMeshProUGUI preguntaText;
    public TextMeshProUGUI resultadoText;
    public Button opcion1, opcion2, opcion3;
    public TextMeshProUGUI pistaText;
    public GameObject ojoPistaObj;
    public ParticleSystem confeti;
    public GameObject perfectoText;

    private float timerPista = 0f;
    private bool pistaActiva = false;

   string[] pistas = {
    "Pista: es una de las estructuras de repeticion mas usadas en C#.",   // for
    "Pista: es la palabra reservada con la que empieza toda clase.",       // class
    "Pista: su nombre viene de 'integer', numero entero en ingles.",       // int
    "Pista: usa dos signos de igual, no uno solo.",                        // Compara valor
    "Pista: la funcion se llama a si misma dentro de su propio cuerpo."   // Recursion
};

    string[] preguntas = {
        "Que estructura repite un bloque de codigo un numero fijo de veces?",
        "Que palabra clave se usa para crear una clase en C#?",
        "Que tipo de dato almacena un numero entero en C#?",
        "Que hace el operador == en una condicion?",
        "Como se llama cuando una funcion se llama a si misma?"
    };

    string[,] opciones = {
        {"for",          "if",           "switch"      },
        {"class",        "void",         "public"      },
        {"string",       "int",          "float"       },
        {"Asigna valor", "Compara valor","Suma valores" },
        {"Herencia",     "Recursion",    "Polimorfismo" }
    };

    int[] respuestasCorrectas = { 0, 0, 1, 1, 1 };
    int preguntaActual = 0;
    int puntaje = 0;

    // ── Unity lifecycle ───────────────────────────────────────────

    void Start() {
        resultadoText.text = "";
        if (perfectoText != null) perfectoText.SetActive(false);
        MostrarPregunta();
    }

    void Update() {
        if (preguntaActual < preguntas.Length && !pistaActiva) {
            timerPista += Time.deltaTime;
            if (timerPista >= 5f) {
                pistaActiva = true;
                MostrarPista();
            }
        }
    }

    // ── Métodos del juego ─────────────────────────────────────────

    void MostrarPregunta() {
        if (preguntaActual >= preguntas.Length) { FinDelJuego(); return; }

        preguntaText.text = preguntas[preguntaActual];
        opcion1.GetComponentInChildren<TextMeshProUGUI>().text = opciones[preguntaActual, 0];
        opcion2.GetComponentInChildren<TextMeshProUGUI>().text = opciones[preguntaActual, 1];
        opcion3.GetComponentInChildren<TextMeshProUGUI>().text = opciones[preguntaActual, 2];

        if (preguntaActual == 0) chef.OnStartCooking();
        if (preguntaActual == 1) chef.OnCodeSuccess();
        if (preguntaActual == 2) chef.SetState(ChefController.ChefState.Idle);

        resultadoText.text = "";
        resultadoText.fontSize = 24;

        // Reinicia pista para la nueva pregunta
        timerPista = 0f;
        pistaActiva = false;
        if (pistaText != null) pistaText.gameObject.SetActive(false);
    }

    void MostrarPista() {
        if (pistaText != null) {
            pistaText.gameObject.SetActive(true);
            pistaText.text = pistas[preguntaActual];
        }
        if (ojoPistaObj != null)
            StartCoroutine(GuinoOjo());
    }

    System.Collections.IEnumerator GuinoOjo() {
        ojoPistaObj.transform.localScale = new Vector3(1f, 0.1f, 1f);
        yield return new WaitForSeconds(0.2f);
        ojoPistaObj.transform.localScale = new Vector3(1f, 1f, 1f);
    }

    public void ResponderOpcion(int opcionElegida) {
        if (opcionElegida == respuestasCorrectas[preguntaActual]) {
            resultadoText.text = "Correcto! Delicioso codigo!";
            resultadoText.fontSize = 48;
            ColorUtility.TryParseHtmlString("#1a7a2e", out Color verdeOscuro);
            resultadoText.color = verdeOscuro;
            chef.OnCodeSuccess();
        } else {
            resultadoText.text = "Incorrecto! Revisa la receta.";
            resultadoText.fontSize = 48;
            ColorUtility.TryParseHtmlString("#b30000", out Color rojoOscuro);
            resultadoText.color = rojoOscuro;
        }

        bool correcto = opcionElegida == respuestasCorrectas[preguntaActual];
        puntaje += correcto ? 1 : 0;
        preguntaActual++;
        Invoke("MostrarPregunta", 2f);
    }
void FinDelJuego() {
    // Oculta la pista al terminar
    if (pistaText != null) pistaText.gameObject.SetActive(false);

    preguntaText.text = "Puntaje: " + puntaje + "/" + preguntas.Length;
    opcion1.gameObject.SetActive(false);
    opcion2.gameObject.SetActive(false);
    opcion3.gameObject.SetActive(false);

    if (puntaje == preguntas.Length) {
        if (confeti != null) {
            confeti.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
            confeti.Play();
        }
        if (perfectoText != null) perfectoText.SetActive(true);
        resultadoText.text = "Perfecto! Eres el chef del codigo!";
    } else {
        resultadoText.text = "Sigue practicando chef!";
    }
    chef.OnCodeSuccess();
}
}