// Coleccionable.cs - Se destruye al tocarlo el robot
using UnityEngine;
public class Coleccionable : MonoBehaviour
{
public int puntos = 10;
private float rotacionVelocidad = 90f;
void Update()
{
// Rotar el ingrediente para que se vea llamativo
transform.Rotate(0f, rotacionVelocidad * Time.deltaTime, 0f);
}
private void OnTriggerEnter(Collider other)
{
// Verifica si el robot toco el ingrediente
if (other.CompareTag("Jugador"))
{
Debug.Log("Ingrediente recolectado! +" + puntos + " puntos");
// Notificar al robot que celebre

            ChefController chef = other.GetComponent<ChefController>();
            if (chef != null) chef.OnCodeSuccess();
// Destruir el ingrediente
Destroy(gameObject);
}
}
}