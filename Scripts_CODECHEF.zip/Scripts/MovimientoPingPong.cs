using UnityEngine;

public class MovimientoPingPong : MonoBehaviour
{
    public Vector3 puntoA = new Vector3(-2f, 0f, 0f);
    public Vector3 puntoB = new Vector3(2f, 0f, 0f);
    public float velocidad = 1f;

    private ChefController chef;
    private Animator animator;
    private bool ibaHaciaB = false;
    private Vector3 posicionObjetivo;

    void Start()
    {
        chef = GetComponent<ChefController>();
        animator = GetComponent<Animator>();
        animator.applyRootMotion = false;
        posicionObjetivo = puntoA;
        transform.position = puntoA;
    }

    void Update()
    {
        float t = Mathf.PingPong(Time.time * velocidad, 1f);

        posicionObjetivo = Vector3.Lerp(puntoA, puntoB, t);

        bool vaHaciaB = t > 0.5f;

        Vector3 direccion;
        if (vaHaciaB)
            direccion = (puntoB - puntoA).normalized;
        else
            direccion = (puntoA - puntoB).normalized;

        if (direccion != Vector3.zero)
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                Quaternion.LookRotation(direccion),
                10f * Time.deltaTime);

        if (vaHaciaB && !ibaHaciaB)
        {
            chef.OnStartCooking();
            ibaHaciaB = true;
            Debug.Log("Robot va hacia el punto B");
        }
        else if (!vaHaciaB && ibaHaciaB)
        {
            chef.SetState(ChefController.ChefState.Idle);
            ibaHaciaB = false;
            Debug.Log("Robot regresa al punto A");
        }
    }

    void OnAnimatorMove()
    {
        transform.position = posicionObjetivo;
    }
}