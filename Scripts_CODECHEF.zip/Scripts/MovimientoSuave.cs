using UnityEngine;

public class MovimientoSuave : MonoBehaviour
{
    public Vector3 puntoA = new Vector3(-2f, 0f, 0f);
    public Vector3 puntoB = new Vector3(2f, 0f, 0f);
    public float velocidad = 0.5f;

    private ChefController chef;
    private Animator animator;
    private float progreso = 0f;
    private bool llego = false;
    private Vector3 posicionObjetivo;

    void Start()
    {
        chef = GetComponent<ChefController>();
        animator = GetComponent<Animator>();
        animator.applyRootMotion = false;

        posicionObjetivo = puntoA;
        transform.position = puntoA;
        chef.OnStartCooking();

        // Desactiva RobotMovimiento al inicio
        RobotMovimiento rm = GetComponent<RobotMovimiento>();
        if (rm != null) rm.enabled = false;
    }

    void Update()
    {
        if (llego) return;

        progreso += velocidad * Time.deltaTime;
        posicionObjetivo = Vector3.Lerp(puntoA, puntoB, progreso);

        if (progreso >= 1f)
        {
            progreso = 1f;
            llego = true;
            posicionObjetivo = puntoB;
            chef.OnCodeSuccess();
            Debug.Log("Robot llego al punto B!");

            // Activa RobotMovimiento cuando termina
            RobotMovimiento rm = GetComponent<RobotMovimiento>();
            if (rm != null) rm.enabled = true;

            // Se desactiva a sí mismo
            this.enabled = false;
        }
    }

    void OnAnimatorMove()
    {
        transform.position = posicionObjetivo;
    }
}