using UnityEngine;

public class RobotMovimiento : MonoBehaviour
{
    public float velocidad = 3f;
    private ChefController chef;
    private Animator animator;
    private bool estabaMoviendose = false;
    private Vector3 movimientoActual;

    void Start()
    {
        chef = GetComponent<ChefController>();
        animator = GetComponent<Animator>();
        animator.applyRootMotion = false;
    }

    void Update()
    {
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        movimientoActual = new Vector3(horizontal, 0f, vertical).normalized;

        if (movimientoActual.magnitude > 0.1f)
        {
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                Quaternion.LookRotation(movimientoActual),
                10f * Time.deltaTime);
        }

        bool seMueve = movimientoActual.magnitude > 0.1f;
        if (seMueve && !estabaMoviendose)
        {
            if (chef != null) chef.OnStartCooking();
            estabaMoviendose = true;
        }
        else if (!seMueve && estabaMoviendose)
        {
            if (chef != null) chef.SetState(ChefController.ChefState.Idle);
            estabaMoviendose = false;
        }
    }

    void LateUpdate()
    {
        if (movimientoActual.magnitude > 0.1f)
            transform.position += movimientoActual * velocidad * Time.deltaTime;
    }
}